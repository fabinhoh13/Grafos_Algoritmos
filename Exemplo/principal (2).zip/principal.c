#include <stdio.h>
#include <stdlib.h>


int main(){
    int A, B;
    scanf ("%d", &A);
    scanf ("%d", &B);
    int X = A + B;

    printf ("X = %d\n", X);

    return 0;

}